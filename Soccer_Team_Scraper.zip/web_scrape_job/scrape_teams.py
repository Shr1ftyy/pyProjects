import bs4 
from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup

allTeams_url = 'http://quikstatsiowa.com/Public/Soccer/TeamStandings.aspx?IDSport=65E5DA09-90C6-45F5-847A-F9A84FD9C5B0'
uClient = uReq(allTeams_url)  
page_html = uClient.read()
uClient.close()
#parse
page_soup = soup(page_html, "html.parser")

containers = page_soup.findAll("div",{"class":"container"})
container = containers[0]

containerFile = open("containers.txt", "w+")
containerFile.write(str(container))

content = container.findAll("div",{"class":"content"})
contentFile = open("content.txt", "w+")
contentFile.write(str(content))

formcontainer = container.findAll("div",{"class":"formcontainer","style":"width: 1000px;"})
formcontainerFile = open("formcontainers.txt", "w+")
formcontainerFile.write(str(formcontainer))

table = container.findAll("table",{"style":"width: 100%; border-collapse: collapse;"})
tableFile = open("table.txt", "w+")
tableFile.write(str(table))

table_columns = container.findAll("tr",{"style":"height: 30px;"})

records = container.findAll("td",{"style":"text-align: center;"})

team_num = 1
team_max = 154
team_statNum = 0 
team_statMax = 15

filename = "team_stats.csv"
f = open(filename, "w")

headers = "Team, Record, GP, G, A, P, Sh, Sh %, SOG, SOG %, CK, PKM, PKA, GA, Avg, S, S %\n"
f.write(headers)

#Teams
for team in table_columns:
	table_columns = container.findAll("tr",{"style":"height: 30px;"})
	table_column = table_columns[team_num]
	team = table_column.td
	team_name = team.a.text

	team_stats = table_column.findAll("td",{"style":"text-align: center;"})
	team_ga = table_column.findAll("td",{"style":"text-align: center; border-left: solid 1px black;"})
	
	rec_stat = team_stats[0].text.strip()
	games_played = team_stats[1].text.strip()
	goals = team_stats[2].text.strip()
	assists = team_stats[3].text.strip()
	points = team_stats[4].text.strip()
	shots = team_stats[5].text.strip()
	shot_percentage = team_stats[6].text.strip()
	shots_on_goal = team_stats[7].text.strip()
	shots_on_goal_percent = team_stats[8].text.strip()
	corner_kicks = team_stats[9].text.strip()
	penalty_kick_made = team_stats[10].text.strip()
	penalty_attempts = team_stats[11].text.strip()
	goals_against = team_ga[0].text.strip()
	goals_against_avg = team_stats[12].text.strip()
	saves = team_stats[13].text.strip()
	saves_percent = team_stats[14].text.strip()
	print(rec_stat)

	# print(team_name)

	f.write(team_name + "," + rec_stat + "," + games_played + "," + goals + "," + assists + "," + points + "," + shots + "," + shot_percentage + "," + shots_on_goal + "," + shots_on_goal_percent + "," + corner_kicks + "," + penalty_kick_made + "," + penalty_attempts + "," + goals_against + "," + goals_against_avg + "," + saves + "," + saves_percent + "\n")

	team_num += 1

	if team_num >= team_max:
		break


### UNUSED CODE - POSSIBLE FUTURE INDEXING UPDATE ###
# for team in table_columns:
# 	table_columns = container.findAll("tr",{"style":"height: 30px;"})
# 	table_column = table_columns[team_num]
# 	team = table_column.td
# 	team_link = team.a["href"]
# 	print("team_link: http://quikstatsiowa.com/Public/Soccer/" + team_link)
# 	team_hyperlink = "http://quikstatsiowa.com/Public/Soccer/" + team_link

# 	team_num += 1

# 	if team_num >= team_max:
# 		break

f.close()


tableColumnsFile = open("table_columns.txt", "w+")
tableColumnsFile.write(str(table_columns))
